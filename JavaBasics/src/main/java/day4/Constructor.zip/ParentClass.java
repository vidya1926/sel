package day4;

public class ParentClass {

	
	int num=10;
	
	public void parent() {
		int x=10;
		System.out.println("I am from parent class" +x);
	}
	
}
